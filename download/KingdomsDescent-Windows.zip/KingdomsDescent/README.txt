Kingdom's Descent (beta) for Windows

1. Unzip this whole folder anywhere (for example your Desktop). Keep every file together.
2. Double-click KingdomsDescent.exe.
3. Windows may say "Windows protected your PC" because the app isn't signed yet:
   click "More info", then "Run anyway". This only happens the first time.

The app always plays the newest beta build, so you never need to download it again for updates.
Online play and co-op work the same as on the website. It needs an internet connection.

Keys: F11 full screen, F5 reload. Your saves in the app are separate from the browser's saves.
