// Kingdom's Descent desktop app: a game window around the live beta (always the newest build, online play works),
// with the build that shipped in this download as a fallback when the beta can't be reached.
const { app, BrowserWindow, shell, session } = require('electron');
const path = require('path');
const URL = 'https://prestonb14.github.io/kingdoms-descent/';

app.commandLine.appendSwitch('disable-renderer-backgrounding');
app.commandLine.appendSwitch('disable-background-timer-throttling');
app.commandLine.appendSwitch('ignore-gpu-blocklist');

function createWindow() {
  const win = new BrowserWindow({
    width: 1600, height: 900, minWidth: 960, minHeight: 540, backgroundColor: '#0d0b10',
    title: "Kingdom's Descent", autoHideMenuBar: true, show: false,
    webPreferences: { backgroundThrottling: false, contextIsolation: true, nodeIntegration: false, spellcheck: false }
  });
  win.setMenuBarVisibility(false);
  win.once('ready-to-show', () => { win.maximize(); win.show(); });
  // mouse capture, fullscreen and the controller are game features: allow them without prompts
  session.defaultSession.setPermissionRequestHandler((wc, perm, cb) => cb(['pointerLock', 'fullscreen', 'clipboard-sanitized-write', 'media'].includes(perm)));
  // links to other sites open in the normal browser
  win.webContents.setWindowOpenHandler(({ url }) => { shell.openExternal(url); return { action: 'deny' }; });
  // F11 full screen, F5 reload, Ctrl+Shift+I developer tools (for bug reports)
  win.webContents.on('before-input-event', (e, input) => {
    if (input.type !== 'keyDown') return;
    if (input.key === 'F11') { win.setFullScreen(!win.isFullScreen()); e.preventDefault(); }
    else if (input.key === 'F5') { win.webContents.reloadIgnoringCache(); e.preventDefault(); }
    else if (input.control && input.shift && (input.key === 'I' || input.key === 'i')) { win.webContents.toggleDevTools(); e.preventDefault(); }
  });
  let fellBack = false;
  win.webContents.on('did-fail-load', (e, code, desc, url, isMain) => {
    if (!isMain || fellBack) return;
    fellBack = true;
    win.loadFile(path.join(__dirname, 'offline.html'));
  });
  win.loadURL(URL, { extraHeaders: 'pragma: no-cache\n' });
}
app.whenReady().then(createWindow);
app.on('window-all-closed', () => app.quit());
